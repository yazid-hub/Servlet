package web;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;


@WebServlet("/servlet")

public class servlet extends HttpServlet{
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException{
        //lecture des paramètres du formulaire html
        String login = request.getParameter("login");
        String password = request.getParameter("mdp");
       String sexe = request.getParameter("sexe");
        String language = request.getParameter("language");
         
        
        String proffesion = request.getParameter("proffesion");
        String musique = request.getParameter("musique");
        String comments = request.getParameter("comments");
        
      
        
        
        
        
        
        System.out.println("login : " + login);
        System.out.println("password : " + password);
      
        System.out.println("language : " + language);
        System.out.println("sexe : " + sexe);

        System.out.println("proffesion : " + proffesion);
        System.out.println("musique : " + musique);
        System.out.println("comments : " + comments);
        
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<body>");
        out.println(login);
        out.println("<br/>");
        out.println(password);
        out.println("<br/>");
        out.println(language);
        out.println("<br/>");
        out.println(sexe);
        out.println("<br/>");
        out.println(proffesion);
        out.println("<br/>");
        out.println("<br/>");
        out.println(comments);
        
        
          
                  
        }
}